package com.mapeamento.controller;

public class TurmaController {

}
