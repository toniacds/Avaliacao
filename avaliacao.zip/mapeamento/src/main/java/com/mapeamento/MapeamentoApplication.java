package com.mapeamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MapeamentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MapeamentoApplication.class, args);
	}

}
