package com.mapeamento.config;

public class SpringSecurityConfig {

}
