package com.prjAvaliacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjAvaliacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
