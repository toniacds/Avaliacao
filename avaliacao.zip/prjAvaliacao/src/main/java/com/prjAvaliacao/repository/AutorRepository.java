package com.prjAvaliacao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.prjAvaliacao.entities.Autor;

public interface AutorRepository extends JpaRepository<Autor, Long> {
	
	@Query(value = "SELECT * FROM Autor l WHERE lower(l.id) LIKE %:id%", nativeQuery = true)
	List<Autor> buscarPorId(@Param("id")int idAutor);
	
	@Query("SELECT l FROM Autor l WHERE l.nome = ?1")
	List<Autor> findByNome(String nome);
	
}
