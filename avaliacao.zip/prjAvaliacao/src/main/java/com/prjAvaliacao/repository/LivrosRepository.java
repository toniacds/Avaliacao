package com.prjAvaliacao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prjAvaliacao.entities.Livros;

public interface LivrosRepository extends JpaRepository<Livros, Long> {

}
