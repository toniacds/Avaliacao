package com.prjAvaliacao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prjAvaliacao.entities.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {

}
