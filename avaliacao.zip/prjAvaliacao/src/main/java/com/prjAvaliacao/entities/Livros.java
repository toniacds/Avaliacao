package com.prjAvaliacao.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Livros")
public class Livros {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idLivros;
	
	private String titulo;
	
	private String ano;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_Autor")
	private Autor autor;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_Categoria")
	private Categoria categoria;
	
public Livros() {
		
	}

public Livros(int idLivros, String titulo, String ano) {
	super();
	this.idLivros = idLivros;
	this.titulo = titulo;
	this.ano = ano;
}

public int getIdLivros() {
	return idLivros;
}

public void setIdLivros(int idLivros) {
	this.idLivros = idLivros;
}

public String getTitulo() {
	return titulo;
}

public void setTitulo(String titulo) {
	this.titulo = titulo;
}

public String getAno() {
	return ano;
}

public void setAno(String ano) {
	this.ano = ano;
}


}
