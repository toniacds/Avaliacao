package com.prjAvaliacao.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Autor")
public class Autor {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long idAutor;

	private String nome;
	
	private String pais;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_livros", nullable = false)
	private Livros livros;
	
public Autor() {
		
	}

public Autor(Long idAutor, String nome, String ano) {
	super();
	this.idAutor = idAutor;
	this.nome = nome;
	this.pais = pais;
}

public Long getIdAutor() {
	return idAutor;
}

public void setIdAutor(Long idAutor) {
	this.idAutor = idAutor;
}

public String getNome() {
	return nome;
}

public void setNome(String nome) {
	this.nome = nome;
}

public String getPais() {
	return pais;
}

public void setPais(String pais) {
	this.pais = pais;
}

public Livros getLivros() {
	return livros;
}

public void setLivros(Livros livros) {
	this.livros = livros;
}


}
