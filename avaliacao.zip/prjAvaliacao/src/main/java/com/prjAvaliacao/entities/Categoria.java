package com.prjAvaliacao.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Categoria")
public class Categoria {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idCategoria;

	private String nome;
	
	private String descricao;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_livros", nullable = false)
	private Livros livros;
	
public Categoria() {
		
	}

public Categoria(int idCategoria, String nome, String ano) {
	super();
	this.idCategoria = idCategoria;
	this.nome = nome;
	this.descricao = descricao;
}

public int getIdCategoria() {
	return idCategoria;
}

public void setIdCategoria(int idCategoria) {
	this.idCategoria = idCategoria;
}

public String getNome() {
	return nome;
}

public void setNome(String nome) {
	this.nome = nome;
}

public String getDescricao() {
	return descricao;
}

public void setDescricao(String descricao) {
	this.descricao = descricao;
}
}
