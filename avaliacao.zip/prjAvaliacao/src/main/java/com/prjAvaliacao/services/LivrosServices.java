package com.prjAvaliacao.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prjAvaliacao.entities.Livros;
import com.prjAvaliacao.repository.LivrosRepository;

@Service
public class LivrosServices {
	
	@Autowired
	private LivrosRepository livrosRepository;
	
	@Autowired
	public LivrosServices(LivrosRepository livrosRepository) {
		this.livrosRepository = livrosRepository;
	}
	
	public List<Livros> getAllLivros(){
		return livrosRepository.findAll();
	}
	
	public Livros getLivrosById(long livroscodigo) {
		return livrosRepository.findById(livroscodigo).orElse(null);
	}
	
	public Livros saveLivros(Livros livros) {
		return livrosRepository.save(livros);
	}

}
