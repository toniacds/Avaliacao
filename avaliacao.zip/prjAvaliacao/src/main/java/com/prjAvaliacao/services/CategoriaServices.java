package com.prjAvaliacao.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prjAvaliacao.entities.Categoria;
import com.prjAvaliacao.entities.Livros;
import com.prjAvaliacao.repository.CategoriaRepository;
import com.prjAvaliacao.repository.LivrosRepository;

@Service
public class CategoriaServices {


	@Autowired
	private CategoriaRepository categoriaRepository;
	
	@Autowired
	public CategoriaServices(CategoriaRepository categoriaRepository) {
		this.categoriaRepository = categoriaRepository;
	}
	
	public List<Categoria> getAllCategoria(){
		return categoriaRepository.findAll();
	}
	
	public Categoria getCategoriaById(long categoriacodigo) {
		return categoriaRepository.findById(categoriacodigo).orElse(null);
	}
	
	public Categoria saveCategoria(Categoria categoria) {
		return categoriaRepository.save(categoria);
	}

}
