package com.prjAvaliacao.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import com.prjAvaliacao.entities.Autor;
import com.prjAvaliacao.repository.AutorRepository;

@Service
public class AutorServices {

	@Autowired
	private AutorRepository autorRepository;

	// construtor que recebe a dependencia
	@Autowired
	public AutorServices(AutorRepository autorRepository) {
		this.autorRepository = autorRepository;
	}

	public List<Autor> getAllAutor() {
		return autorRepository.findAll();
	}

	public Autor getAutorById(long autorcodigo) {
		return autorRepository.findById(autorcodigo).orElse(null);
	}

	public Autor saveAutor(Autor autor) {
		return autorRepository.save(autor);
	}
	
	// query buscar
	@Query
		public List<Autor> buscarPorId(int idAutor) {
			return autorRepository.buscarPorId(idAutor);
		}

		public List<Autor> buscarPorNome(String nome) {
			return autorRepository.findByNome(nome);
		}

}
