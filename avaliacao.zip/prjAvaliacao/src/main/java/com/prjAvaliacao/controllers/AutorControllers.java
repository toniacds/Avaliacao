package com.prjAvaliacao.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prjAvaliacao.entities.Autor;
import com.prjAvaliacao.entities.Categoria;
import com.prjAvaliacao.services.AutorServices;


@RestController
@RequestMapping("/autor")
@CrossOrigin(origins = "http://localhost:8080/autor/")
public class AutorControllers {
	
	private final AutorServices autorServices;
	
	@Autowired 
	public AutorControllers(AutorServices autorServices) {
		this.autorServices = autorServices;
	}

	@GetMapping("/{id}")
	public ResponseEntity<Autor>findAutorById(@PathVariable int idAutor){
		Autor autor = autorServices.getAutorById(idAutor);
		if (autor != null) {
			return ResponseEntity.ok(autor);
		}else {
			return ResponseEntity.notFound().build();
		}
	}
	
	@GetMapping("/")
	public ResponseEntity<List<Autor>>findAllUsuariocontrol(){
		List<Autor>autor = autorServices.getAllAutor();
		return ResponseEntity.ok(autor);
	}
	
	@PostMapping("/")
	public ResponseEntity<Autor>insertUsuarioControl(@RequestBody Autor autor){
		Autor novoautor = autorServices.saveAutor(autor);
		return ResponseEntity.status(HttpStatus.CREATED).body(novoautor);
	}

	//query method buscar 
		@GetMapping("/id/{id}")
		public List<Autor> buscarPorId(@PathVariable int id){
			return autorServices.buscarPorId(id);
		    }
		
		@GetMapping("/nome/{nome}")
		public List<Autor> buscarPorNome(@PathVariable String nome){
			return autorServices.buscarPorNome(nome);
		}

}
